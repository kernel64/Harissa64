# Harissa64 🌶️

**A Nintendo 64 emulator for the Xbox 360, built as a native `.xex` for homebrew dashboards such as Aurora.**

Harissa64 is named after harissa, the Tunisian chili paste. It is a fork of [Xenon64](https://github.com/bromurok/Xenon64) by bromurok, itself a port of [Mupen64-360](http://www.libxenon.org/) (GliGli's libxenon port of Wii64/Mupen64 with the Rice video plugin) to the official Xbox 360 SDK. Running as a regular `.xex` instead of a libxenon `.elf` means it launches straight from Aurora, FreeStyle Dash or the dashboard on a modded console, returns to it when you quit, and uses the console's own drivers for video, audio and controllers.

> **For educational purposes.** Harissa64 is a homebrew project made to learn about emulation and Xbox 360 development. Use it only with ROMs dumped from N64 cartridges you own. No ROMs are provided, and none will be.

---

## Features

- **ROM browser** — lists `.z64`, `.n64`, `.v64` and `.zip` ROMs, with folders, long-name scrolling and Xbox 360 button prompts.
- **Zipped ROMs** — loaded directly from `.zip` (deflate or stored), with CRC check.
- **Configurable ROM folder** — pick any folder on `game:`, `Hdd1:` or a USB drive (`Usb0:`–`Usb2:`) from the settings.
- **In-game pause menu** — **hold Back for about a second** (Back + Start is the Aurora/DashLaunch screenshot combo): resume, save or load a state (10 slots), change settings, or quit to the ROM list without rebooting.
- **Save states** — stored in `mupen64-360\sstates\` (falls back to `cache:\` when the game folder is read-only).
- **Audio** — XAudio2 output at the game's native rate; audio-driven frame limiter. Includes the MusyX audio microcode (Factor 5 games such as *The World Is Not Enough*, *Rogue Squadron*, *Resident Evil 2*).
- **Settings** — controller layout (6 presets), frame limiter, frame skip (renders one frame in two, a large speed-up on real hardware), screen (full width, or the original 4:3 picture between black bars on a 16:9 TV), an FPS counter in the top-left corner (green at full speed), CPU timing (Fast/Faster give the game fewer emulated CPU cycles per frame: a speed hack for scenes that use the whole frame), VSync (off by default: waiting for vblank costs emulation time), audio on/off, debug log. Saved to `mupen64-360\harissa64.ini`.
- **Aurora friendly** — quitting returns to the default dashboard (`XLaunchNewImage`).

## Requirements

- An Xbox 360 able to run unsigned code (RGH/JTAG) with a homebrew dashboard such as Aurora.
- ROMs dumped from your own N64 cartridges. **No ROMs are provided or will be provided.**

## Installation

Download the latest `Harissa64-<version>.zip` from the [Releases](https://github.com/kernel64/Harissa64/releases) page (the same zips are kept in the [`release`](release/) folder), extract it, and copy the `Harissa64` folder to the console, for example to `Hdd1:\Emulators\Harissa64\`:

```
Harissa64\
├── default.xex         the emulator
├── vs.xpu, ps_fb.xpu   shaders
├── roms\               put your ROMs here (subfolders are fine)
└── mupen64-360\        configuration and saves
    ├── mupen64plus.cfg, RiceVideo.cfg, RiceVideoLinux.ini, mupen64.ini
    ├── harissa64.ini   front-end settings (created on first save)
    ├── saves\          in-game saves
    └── sstates\        save states
```

Then add the parent folder (e.g. `Hdd1:\Emulators\`) to Aurora's scan paths: the emulator shows up as **Harissa64**, with its own icon (title ID `48413634`). The `roms`, `saves` and `sstates` folders are created automatically if they are missing. Coming from Xenon64? Your `xenon64.ini` settings are picked up automatically.

### ROM file names

The Xbox 360 file system (FATX) only accepts file names that are **at most 42 characters long** and made of letters, digits, spaces and `` ! # $ % & ' ( ) - . @ [ ] ^ _ ` { } ~ ``. Commas — very common in No-Intro names such as `(En,Fr,De)` — as well as `+`, `;`, `=` and accented letters are not allowed. Such files are shown **in red** in the browser and cannot be opened.

Fix a whole folder on your PC before copying it. The script also cleans names left messy by other tools (doubled or truncated extensions such as `.zip.zip.zip`, the `[!]` tag), sets the extension from the file content, and reports duplicates and files that are not ROMs:

```powershell
.\tools\fix_rom_names.ps1 -Path D:\N64\roms -WhatIf   # preview
.\tools\fix_rom_names.ps1 -Path D:\N64\roms           # rename
```

`Super Mario 64 (Europe) (En,Fr,De).zip` becomes `Super Mario 64 (Europe) (En-Fr-De).zip`.

## Controls

**Browser**

| Button | Action |
|---|---|
| A / Start | Play the ROM / open the folder |
| B | Parent folder |
| LB / RB | Page up / down |
| Y | Settings |
| Back | Exit to the dashboard |

**In game** (default layout *Stick / D-pad / C-buttons*)

| Xbox 360 | Nintendo 64 |
|---|---|
| Left stick | Analog stick |
| D-pad | D-pad |
| Right stick | C buttons |
| A / B | A / B |
| X, Y, LT or RT | Z |
| LB / RB | L / R |
| Start | Start |
| **Back (hold ~1 s)** | **Pause menu** |

Other layouts swap the roles of the stick, D-pad and C buttons; change them in the settings or the pause menu.

## Compatibility

Booting and rendering have been checked in the Xenia emulator for: *Super Mario 64*, *Mario Kart 64*, *Mystical Ninja Starring Goemon*, *007: The World Is Not Enough*. Real-hardware results are welcome.

Known limitations:

- **Speed** — the R4300 CPU is emulated by a pure interpreter, so many games run below full speed on a real console (Xenia on a fast PC is quicker).
- **Graphics** — framebuffer effects and some texture formats may be wrong in some games.
- **Audio** — games whose audio microcode is not recognised run silently.
- **Saves** — save states work in Xenia; in-game saves (EEPROM, SRAM, Flash, Controller Pak) are written to `mupen64-360\saves\`. Neither has been tested on real hardware yet. Save states from one Harissa64 version may not load in another.

## Building

Requirements:

- Visual Studio 2010 (Visual C++)
- Microsoft Xbox 360 SDK (XDK) with its Visual Studio 2010 integration — not provided here.

Open `xbox64.sln` and build the **Release | Xbox 360** configuration, or from a command prompt:

```bat
call "%VS100COMNTOOLS%..\..\VC\vcvarsall.bat" x86
msbuild xbox64.sln /p:Configuration=Release /p:Platform="Xbox 360"
```

The output is `xbox64\Release\harissa64.xex` (the solution and project files keep their historical `xbox64` names).

### Making a release

```powershell
.\build_release.ps1            # rebuild + package
.\build_release.ps1 -NoBuild   # package the existing build
```

This rebuilds Release, checks the output and writes `release\Harissa64-<version>.zip` (version from the `VERSION` file). The zip holds a single `Harissa64\` folder — `default.xex`, shaders, stock configs, empty `roms\`, `saves\` and `sstates\`, `README.md`, `LICENSE` and `INSTALL.txt` — ready to extract and copy to the console. Bump `VERSION` before building a new release; release zips are committed under `release/` (older ones are kept). Pushing a new zip to `master` makes the `Release` GitHub Actions workflow publish it as a GitHub release tagged `v<version>`.

The title name and icon shown by Aurora come from `xbox64\title\harissa64.xlast` and `icon.png` (64×64), compiled to a SPA by the build and embedded in the `.xex`; the title ID is set in `xbox64\title\xex.xml`. See [CLAUDE.md](CLAUDE.md) for an overview of the code layout and of the debugging options (debug log, `autoload=` for direct boot).

## Credits

- **Mupen64** by Hacktarux and the Mupen64 team; **Mupen64Plus** team (core, RSP HLE, MusyX HLE).
- **Wii64** team (tehpola, sepp256, emu_kidid and others).
- **Rice Video** by Rice1964.
- **Mupen64-360** by GliGli (Xbox 360 port), Ced2911 (GUI library), Razkar (backgrounds), and the libxenon contributors.
- **Xenon64**, the original XDK port this project forks, by bromurok.
- **zlib** by Jean-loup Gailly and Mark Adler.

## License

Harissa64 is free software released under the **GNU General Public License, version 2 or later** — see [LICENSE](LICENSE). It is derived from GPL code and must stay under the GPL: if you distribute binaries, you must also make the corresponding source code available.

`source/zlib/` is under the zlib license (see `source/zlib/LICENSE`).

Nintendo 64 is a trademark of Nintendo. Xbox and Xbox 360 are trademarks of Microsoft. This project is not affiliated with or endorsed by either company.
